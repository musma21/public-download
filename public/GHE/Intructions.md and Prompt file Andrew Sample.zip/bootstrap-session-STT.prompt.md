---
mode: agent
model: gpt-5-mini
---
# Session Bootstrap for STT

**Note:**

- A session = multiple chapters.
- Each session or chapter has its own folder (hierarchical structure)
- A session may have only a single chapter.
- A session with a single chapter has no sub-folder.
- MUST USE the Default model unless explicitly marked with `[LLM: model-name]`

**Instructions:**
- `## Number` : step, `* Number` : sub-step
- `[WAIT]` = MUST pause for any user input.
- Validate user input before proceeding, if required. Otherwise, auto-continue.
- At each step, MUST notify which runtime model is used.
- `[LLM: model-name]` = MUST switch to specified model for this step ONLY
- `[/LLM]` = MUST return to the default model
- List output files after each step, if any.

**Response Rules:**
* Terse, and no narration
* Format:
- [Action]
- [Result]
- [Ask]

---

## 1. Get Session Title

* `[WAIT]` {input:session-title:What is the session title for this new session?}

## 2. Confirm Multi-Chapter and Create Folder

* 1. `[WAIT]` {input:is-multi-chapter:Does the session have multiple chapters? (Y/N)}
* 2. Create `scripts/tmp/${session-title}/`
* 3. Change working directory to `scripts/tmp/${session-title}/`
* 4. Run `cd ${workspaceFolder}/scripts/tmp/${session-title}/`

## 3. Get Audio File

* `[WAIT]` Ask user to place `${session-title}-audio.mp3` → reply "done" or "skip"
* > if "skip", `[WAIT]` Ask user to which step s/he want to skip and proceed, and do follow the direction.

## 4. Generate JSON from Azure STT

* `[WAIT]` Ask user to (include the clickable link as well):
* Upload audio to [Azure STT Batch Transcript](https://ai.azure.com/build/playground/speech/speechtotext?NewUX=true&Trigger=Banner&tid=f84ea5a1-91db-4a78-8991-bf0dfbe3dc3a&connectionName=ai-jimin&wsid=/subscriptions/d5d398e6-82c3-42fa-a69c-9df32891bc63/resourceGroups/rg-sunyi/providers/Microsoft.MachineLearningServices/workspaces/jimin-english-class#batch) and save as `${session-title}.json` → reply "done" or "skip"; if "skip", skip to the next step.

## 5. Generate Initial Text and VTT

* 1. Run `../../generate-vtt-from-JSON.py`  on `${session-title}.json`

* 2. Run `../../extract-transcript-from-JSON.sh` on `${session-title}.json`

* 3. `[WAIT]` 🧠 Ask user to review/edit `${session-title}.vtt` → reply "done" or "none"; and inform `merge-vtt-cue.py` or `split-vtt-cue.py` can be used for editing, and by putting a period, it could be easier to split a que.

## 6. Remove Unwanted Spans (Optional)

* `[WAIT]` Ask user for spans to remove (format: `"HH:MM:SS.mmm --> HH:MM:SS.mmm"` per line), or "none"

* If provided, run `../../remove-vtt-spans.py` with those spans on audio and VTT files

## 7. Refine Text with AI

`[LLM: claude-sonnet-4.5]`
`[WAIT]` Notify user to change to **claude-sonnet-4.5**.

* Read `${session-title}-text.txt` and refine, following these rules:

**CRITICAL: Preserve pronunciation**
- Do NOT add, remove, or substitute words
- Audio must match final text

**Allowed edits:**
1. **Paragraphing**: Logical breaks (no content change)
2. **Homophone standardization**: Only if pronunciation identical
   - ✅ "World War 2" → "World War II"
   - ✅ "8 year" → "eight-year"
3. **Punctuation**: Add/refine (em dash, colon, hyphen, serial comma); DO NOT add a hyphen before a conjunction; instead, end the sentence with a period.

**Suspected STT errors:**
If context suggests different word with similar pronunciation:
- Format: `correct-word (original-stt-word?)`
- Example: `brewing (brooding?)`
- Flag: ⚠️ ATTENTION REQUIRED: Potential STT transcription error

**Output:**
1. Backup original: `${session-title}-text.txt.org`
2. Overwrite with refined: `${session-title}-text.txt`
3. Create log: `{session-title}-text.log.md` with Summary section listing all ⚠️ ATTENTION items.
4. Create an overview summary of the text as `${session-title}-summary.txt` less than 100 words.

`[/LLM]`

* `[WAIT]` 🧠 Ask user to review/edit `${session-title}-text.txt` → reply "done" or "none"

## 8. Retouch the text of VTT based on the orginal text

* 1. Run `../../replace-vtt-text.py` on `${session-title}.vtt` and `${session-title}-text.txt`.

* 2. `[WAIT]` 🧠 Ask user to review/edit `${session-title}.vtt` → reply "done" or "none"; and inform `../../merge-vtt-cue.py` or `../../split-vtt-cue.py` can be used for editing.

## 9. Generate translation

`[LLM: claude-sonnet-4.5]`
`[WAIT]` Notify user to change to **claude-sonnet-4.5**.

* Loop until user says "N":
  > - Ask target language for translation
  > - Store ISO639-1 code as `${lang}`
  > - Translate `${session-title}-text.txt` → save as `${session-title}-${lang}.txt`
  > - Ask: "Review `${session-title}-${lang}.txt` and translate another language? (Y/N)"
  > - If Y, repeat loop

`[/LLM]`

## 10. Generate a pronunciation drill VTT

* 1. `[WAIT]` 🧠 Ask user to create/edit/review `${session-title}-pronounce.txt` → reply "done" or "skip"; if "skip", skip to the next step.
* 2. Run `../../generate-pronounce-SSML.py` on `${session-title}-pronounce.txt`
* 3. `[WAIT]` 🧠 Show the output from the above script "as it is". (SSML upload -> save MP3)
(Guide the user to use `../../merge_mp3.sh` if multiple audio files has been generated)
* 4. `[WAIT]` Ask user if `${session-title}-pronounce.MP3` is now saved → reply "done"
* 5. Run `../../generate-pronounce-VTT-direct.py` on `${session-title}-pronounce.MP3`
* 6. `[WAIT]` 🧠 Ask user to review/edit `${session-title}-pronounce.vtt` → reply "done"

## 11. Generate Vocabulary

`[LLM: claude-sonnet-4.5]`
`[WAIT]` Notify user to change to **claude-sonnet-4.5**.

* Read `${session-title}-text.txt` and extract vocabulary items following these rules:

**Selection Criteria:**
- **Target Level**: Intermediate to Advanced learners (CEFR B1-early C1)
- **Selection Principle**:
  - Choose items likely unfamiliar to an average B2 learner
  - OR crucial for understanding the text’s argument, tone, or logic
- **Priority Items**:
  1. Academic/formal vocabulary (e.g., "invasion", "colonial", "dictatorship")
  2. Multi-word expressions & idioms (e.g., "in a nutshell", "on the decline")
  3. Phrasal verbs (e.g., "turn into", "flare up")
  4. Collocations (e.g., "breaking news", "civil wars")
- **Skip**: Basic words (A1-A2 level), proper nouns, numbers

**Definition Style:**
- concise, learner-friendly Korean
- avoid dictionary-style sentences
- explain the meaning of the word in the sentence (and note the original meaning if it differs)
- use short phrases where possible

**Output Format:**
Each line must follow this exact structure:
```
* word/phrase | part-of-speech :: definition | Example: sentence from text
```
**Format Rules:**
1. **Prefix**: Always start with `* ` (asterisk + space)
2. **Term**:
   - Word or phrase **as it is in the orginal sentence**
   - use lowercase unless proper noun
3. **POS Tag Rules:**
   - POS required for single-word items
   - optional for phrases/idioms
   - omit only if genuinely unclear
   - `adjective`, `noun`, `verb`, `adverb`, `phrase`, `idiom`, `phrasal verb`, `preposition`
   - Format: `term | pos :: definition`
4. **Separator**: Use `::` between term/pos and definition
5. **Definition**:
   - If the term == verb && irregular verb, show `(base form)`
   - If the term == noun && has an irregular plural form, show `(singular form)`
   - If the term contains a phrasal verb (with or without inserted words),
     show `(base verb + particle)` extracting only the core phrasal verb components
   - Natural Korean translation/explanation (한국어로 작성)
6. **Example Rules** (optional):
   - Add `| Example: ` followed by original sentence from `${session-title}-text.txt`
   - Keep example under 15 words
   - Choose the shortest meaningful clause

**Sample Entries:**
```
* violent | adjective :: 폭력적인, 격렬한
* decline | noun :: 감소, 줄어듦 | Example: A decline in violence
* In a nutshell | idiom :: 한마디로 말하면, 아주 간단히 말해
* turn into | phrasal verb :: ~로 바뀌다, 변하다
* despite | preposition :: ~에도 불구하고
```
**Processing Steps:**
1. Read full text content
2. Identify 20-40 vocabulary items based on selection criteria
3. Sort by appearance order in text (maintain reading flow)
4. Generate output following exact format
5. Save as `${session-title}-voca.md` in UTF-8 (with Unix style Line ending: LF)

`[/LLM]`

* `[WAIT]` 🧠 Ask user to review/edit `${session-title}-voca.md` → reply "done" or "none"

## 12. Session logo

* `[WAIT]` 🧠 Ask user to save `${session-title}-cover.png` → reply "done" or "skip"; if "skip", skip to the next step.

## 13. Recommend each chapter span

* If `${is-multi-chapter}`==N, then skip this step.
* Run `../../recommend-chapter-spans.py` on `${session-title}.vtt`
* Read `${session-title}-chapters.json` and print full JSON content (do not summarize)
* `[WAIT]` Accept chapter split? (Y/N)
  - Y: continue to next step
  - N: ask user for `--max-duration` value, re-run script, repeat from step 3

## 14. Split files into chapters

* If `${is-multi-chapter}`==N, then skip this step.

* Run `../../split-chapter-spans.py` on `assets/${session-title}-chapters.json`
** `[WAIT]` 🧠 Ask user to review each sub chapter folers → reply "go"

## 15. Split the translated text to each chapter

* If `${is-multi-chapter}`==N, then skip this step.

`[LLM: claude-sonnet-4.5]`
`[WAIT]` Notify user to change to **claude-sonnet-4.5**.

* Split the translated text file `${session-Title}-ko.txt` into corresponding chapter-specific translation files `${session-Title}-#-ko.txt` for each sub-chapter folder under the `${session-Title}` session directory.

**Requirements:**

- Read the full translation from `${session-Title}-ko.txt`
- Match/align content with each chapter's `${session-Title}-#-text.txt`
- Save split translations as `${session-Title}-#-ko.txt` in respective chapter folders
- Do NOT add, remove, or substitute words. Just appropriately split
- MUST keep the format of `${session-Title}-ko.txt` even in the split translations
- No need to ask users to review the results. Just go to proceed

`${session-Title}-ko.txt`
`[/LLM]`

## 16. Finalize the sesson bootstrap
** `[WAIT]` 🧠 Ask user to review session or chapter folers → reply "go" or "skip"; if "skip", skip to the next step.

1. Run `../../split-chapter-spans.py` on `assets/${session-title}-chapters.json` with `--finalize`
2. Run `../../update-sidebar.py ${session-title}`
