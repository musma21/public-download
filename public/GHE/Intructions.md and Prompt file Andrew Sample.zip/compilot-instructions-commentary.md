<!--
	Copilot Repository Instructions – Joon's English Class
	Version: 1.0 (2025-11-08)
	Purpose: Tailored guardrails & context for AI assistance in this specific repo.
	Priority Order: Security > Integrity > Clarity > Performance > Convenience.
-->
> Metadata block keeps humans and agents aligned on context, version, and priority order.

# Copilot Instructions (Template First, Repo-Specific Later)

> Title matches the source file so diff reviewers can spot drift immediately.

> Commentary rationale: see [`.github/compilot-instructions-commentary.md`](.github/compilot-instructions-commentary.md) for condensed reasoning and repo-specific examples.
> Cross-link stays unchanged so automation and humans can find this commentary.

## 1. Security & Safety

No secrets; never suggest inline credentials. Escape injected text; retain XSS guards. Heavy frameworks (React/Vue/etc.) only by explicit request. Ask before changing version format, hook behavior, tracked modules, encryption approach, or refactoring >3 files.
> Protects credentials, automation, and minimizes unreviewed framework or refactor churn.

## 2. Performance Guidelines

Clarity first. Defer caching until measured bottleneck (e.g. repeated session navigation slowdown). Avoid speculative service worker additions without approval.
> Prevents premature optimization and surprise offline tooling that might break learners.

## 3. Changes Requiring Confirmation

Public API rename/remove; hook logic edits or new hooks; tracking module list changes; significant folder moves; new external dependency or package additions.
> Captures high-risk edits so the user can green-light them before work starts.

## 4. Response Protocol

Significant = (>3 files) OR version format change OR loader order change OR new dependency OR hook semantics change. For significant: plan + impact + wait for user yes. For small: patch + concise diff summary. Always report Build/Lint/Test PASS/FAIL or provide manual checklist if tests absent.
> Codifies review expectations and keeps validation status explicit.

## 5. Localization & Content

Default language for persistent artifacts (README, instructions, code comments, commit messages, GitHub Issues, Pull Requests, Actions, Agent Tasks) is English unless explicitly requested otherwise. Korean responses only on user request; do not persist Korean code comments unless instructed.
> English-only default prevents localization drift and ensures all collaboration artifacts (including GitHub Issues, PRs, Actions, and Agent Tasks) are accessible to all contributors without language barriers.

## 5. Localization & Content

Default language for persistent artifacts (README, instructions, code comments, commit messages, GitHub Issues, Pull Requests, Actions, Agent Tasks) is English unless explicitly requested otherwise. Korean responses only on user request; do not persist Korean code comments unless instructed.
> English-only default prevents localization drift and ensures all collaboration artifacts (including GitHub Issues, PRs, Actions, and Agent Tasks) are accessible to all contributors without language barriers.

## 6. Documentation Protocol

Major change → update: root `README.md`, affected module top comments, changed/new functions as well. Keep commentary file in sync with this file. Prompt: "Update documentation artifacts now? (yes/no)". When referencing another Markdown file in this repository, always include a Markdown link to its relative path (must not omit the link).
> Ensures docs track behavior, enforces explicit cross-linking to avoid stale textual references, and prompts the user when learner-facing text might shift.

## 7. Maintenance & Review on various instructions

**Scope:** This section applies to all instruction files in this repository:

- `.github/copilot-instructions.md` (this file)
- `.github/*-instructions.md` (any additional instruction variants)
- `AGENTS.md` (agent configuration and command style)

DO:

- **MANDATORY: Update corresponding commentary file IMMEDIATELY after ANY change to instruction files. No exceptions.**
  - `.github/copilot-instructions.md` → `.github/compilot-instructions-commentary.md`
  - `AGENTS.md` → `.github/AGENTS-commentary.md`
- Compress wording when editing.
- Provide delta summary for broad edits.
- Ask: "Apply condensed update? (yes/no)" before large condensation.
- Keep files skimmable (copilot-instructions <~150 lines, AGENTS <~70 lines) while preserving guardrails.
- Structure commentary so each section repeats instruction text verbatim followed by blockquoted human notes.

DON'T:

- Paraphrase instruction text inside commentary (must stay verbatim).
- Add new inline comments in instruction files (explanations live only in commentary).
- Skip commentary sync after changing any section of any instruction file.

> Expanded scope to cover all instruction files (copilot-instructions.md, AGENTS.md, and variants). MANDATORY commentary sync enforced across all files with explicit file-to-commentary mappings. Per-file length guidelines added to maintain skimmability.

## 8. Command Style and Conversation Tones

**Shell/Git/GitHub Operations (all contexts):**

- One command per line; do not chain with `&&`, `;`, or pipes purely for batching.
- For multi-step tasks, list commands separately (numbered or bullet) and execute sequentially.
- Provide brief context when multiple commands are required instead of compaction.

**Do / Avoid Quick Reference:**

Do: focused patches, clear commits, keep naming/version rules. Avoid: eval reintroduction, manual timestamp hacking, suffix repurposing, large refactors without confirmation.

> Agent role rationale: see [`.github/AGENTS-commentary.md`](.github/AGENTS-commentary.md).

> Command style moved from AGENTS.md to apply universally across all contexts (agent-tagged or not). Prevents command chaining errors and improves review clarity. Do/Avoid quick reference retained for common guardrails.

---
> Divider separates global guidance from repo specifics; do not remove.

## 9. Repository Context (Repo-Specific)

Docsify site under `docs/`; each session folder contains `assets/` with text, translation, audio, vocabulary, grammar, pronunciation, quiz, optional cover image. Per-session `README.md` is a minimal placeholder populated at runtime by `common.js` and `render.js`.
> Summarizes how runtime population works so edits target the right files.

## 10. Asset Naming (Repo-Specific, Strict)

Every asset: `<SessionTitle><suffix>.<ext>`; optional leading `NNN.` numeric prefix for ordering only. Suffix table:

| Type                | Suffix     | Ext  | Example                                          | Notes                        |
| ------------------- | ---------- | ---- | ------------------------------------------------ | ---------------------------- |
| Main text           | -text      | .txt | 011.Is-Working-Well-1-text.txt                   | UTF-8; line breaks preserved |
| Korean translation  | -ko        | .txt | 011.Is-Working-Well-1-ko.txt                     | Optional                     |
| Full audio          | -audio     | .mp3 | 011.Is-Working-Well-1-audio.mp3                  | Single narration             |
| Pronunciation list  | -pronounce | .txt | 011.Is-Working-Well-1-pronounce.txt              | One term per line            |
| Pronunciation audio | -pronounce | .mp3 | 011.Is-Working-Well-1-pronounce.mp3              | Mirrors list order           |
| Vocabulary          | -voca      | .md  | 011.Is-Working-Well-1-voca.md                    | Parsed list                  |
| Grammar             | -grammar   | .md  | 011.Is-Working-Well-1-grammar.md                 | Markdown allowed             |
| Cover image         | -cover     | .png | 011.Is-Working-Well-1-cover.png                  | Optional                     |
| Quiz                | -quiz      | .txt | 010.Is-The-World-Getting-More-Violent-1-quiz.txt | `:::::::::` splits Q/A       |

Rules: strict path `docs/<SessionFolder>/assets/<SessionTitle><suffix>.<ext>`; missing optional assets fail silently; new asset type requires suffix definition + README + instructions + loader logic update; never repurpose a suffix.
> Enforces predictable asset discovery and prevents loader/tooling drift.
> Example asset: [`docs/011.Is-Working-Well-1/assets/Is-Working-Well-1-text.txt`](../docs/011.Is-Working-Well-1/assets/Is-Working-Well-1-text.txt)

## 11. Versioning Model (Repo-Specific)

Format: `YYYYMMDDTHHMMSS-<shortSHA>-<module>` (Asia/Seoul timestamp; parent commit short SHA). Baseline `19700101T000000`. Tracked: `common`, `render`, `audiosyncCss`, `customCss`. Parent SHA lag intentional.
Hooks: pre-commit updates `BUILD_SHA` + staged module versions; pre-push appends unique `<version> : <commit-subject>` lines to `version.log` (manual commit later).
> Maintains deterministic cache busting and traceability through hooks.

## 12. Loader Order (Repo-Specific, Critical)

Exact sequence: `version.js` (seed) → apply versioned CSS → `common.js` → `render.js` → Docsify. Changing order risks permanent “Loading …”.
> Loader order is fragile; this reminder keeps hydration from freezing.
> Sequence files: [`docs/assets/js/version.js`](../docs/assets/js/version.js) → [`docs/assets/js/common.js`](../docs/assets/js/common.js) → [`docs/assets/js/render.js`](../docs/assets/js/render.js)

## 13. Debug & Diagnostics (Repo-Specific)

`?debug=1` enables `window.JS_DEBUG.common` & `.render`; footer shows versions only when debug ON. Provide `window.setAllDebug(v)` helper. Keep logging minimal; gate all verbose output behind debug flag.
> Keeps noisy logging gated and documents the toggles we expect.

## 14. Documentation Protocol (Repo-Specific Detail)

Triggers: loader order, version format, asset naming, parsing logic, audio sync, debug flags.
Approval: ASK before editing learner-facing `docs/README.md` or `docs/_sidebar.md`.
Flow: list impacted behavior → patch only changed facts → seek approval for learner-facing → apply → quick stale reference scan.
Risk if skipped: race conditions, silent asset ingestion failures.
> Aligns learner-facing docs with backend behavior and warns about silent breakage.

<!-- Update Log removed; rely on VCS history. -->
> Rely on git history instead of reviving manual logs.

## 15. README Separation (Repo-Specific)

Root [`README.md`](../README.md) holds technical/process details: architecture, asset naming table (authoritative), versioning model, loader order, local `docsify serve docs` command, contribution/workflow notes.
[`docs/README.md`](../docs/README.md) stays strictly learner-facing (welcome + navigation).

Do NOT copy technical tables, shell commands, hooks, version/debug flag details into `docs/README.md`; do NOT move learner navigation guidance into the root beyond a brief pointer. If either README drifts outside scope, update this section first and sync the commentary.
> Condensed for fast scanning; preserves scope boundaries and explicit prohibitions without redundant DO/DON'T blocks.

---
> Maintains closing separation before the final directive.
## 16. Andrew's Personal Preference

### Daily Work Session Management

**`/init-today`** - Start daily work session:
1. Review last session from [`journal.md`](../journal.md): content + remaining TO-DO
2. Ask user:
   - Today's must-finish goal (desired state, not implementation details)
   - Target completion time
   - Rough task breakdown
3. Generate detailed task list → present for user confirmation
4. Create new [`journal.md`](../journal.md) section with today's date + user inputs (commit only, no push)
5. Navigate open terminal to workspace root directory

> Establishes daily work rhythm: review context → set goals → plan → commit intent. Terminal navigation ensures commands run in correct workspace root. Commit-only (no push) allows user to review/amend before sharing.

**`/check-today`** - Progress check with active intervention:
1. Execute `date "+%Y-%m-%d %H:%M:%S"` in terminal to get current timestamp
2. Read target completion time from journal.md (use extended time if previously adjusted)
3. Calculate time remaining vs incomplete tasks
4. Report: current time, target time, time remaining, incomplete tasks count
5. Assess bottleneck indicators:
   - Single task consuming >3 hours without progress
   - Tasks unrelated to stated goal (from "## 목표")
   - Perfectionist polish vs essential functionality
6. If bottlenecked: propose moving time-consuming non-essential tasks to `## Backlog` subsection
   - Wait for user agreement
   - If agreed: update journal.md (add `## Backlog`, move tasks from TO-DO), commit only
7. If user insists on continuing: propose extended deadline
   - Update "## 마감 시간" field directly
   - Add `## 마감 시간 변경 이력` subsection with timestamp + reason
   - Commit journal.md (no push)
8. Next `/check-today` must use the extended deadline for calculations

> Active coaching tool, not passive report. AI identifies time sinks (especially >3h on one task), challenges goal alignment, and negotiates scope cuts or deadline extensions. Journal.md becomes living document tracking commitments and adjustments. Extended deadlines propagate to subsequent checks, preventing false urgency.

**`/break-today`** - Start break (meal, meeting, etc.):
1. Execute `date "+%Y-%m-%d %H:%M:%S"` to get break start time
2. Ask user: reason for break, expected return time
3. Add `## 휴식 기록` subsection to journal.md if not exists
4. Record: `- HH:MM-??: [reason]` (end time TBD until /resume-today)
5. Commit journal.md (no push)

> Captures interruptions (meals, meetings) separately from work progress. Expected return time helps set mental checkpoint but doesn't auto-extend deadline.

**`/resume-today`** - Return from break:
1. Execute `date "+%Y-%m-%d %H:%M:%S"` to get resume time
2. Update last break entry in `## 휴식 기록`: replace `??` with actual return time
3. Commit journal.md (no push)
4. Note: deadline remains unchanged (break time does NOT extend deadline)

> Closes break record with actual duration. Keeps deadline pressure intact—user must explicitly call /check-today to negotiate extension if needed.

**`/drop-today`** - Emergency interruption:
1. Show: completed work, drop timestamp, elapsed time, backlog items
2. Wait for user confirmation
3. Update [`journal.md`](../journal.md) with interruption record

> Captures interrupted work state cleanly so next session can resume or reprioritize without losing context.

**Auto-check (when past target time):**
- Detect user still working after target completion time
- Ask: extend target time or invoke `/drop-today`?

> Proactive intervention prevents silent deadline drift. Forces explicit decision: adjust plan or acknowledge incomplete state.

**`/close-today`** - Successful completion:
1. Show: completed work, completion timestamp, total elapsed time, lessons learned (if any)
2. Ask: remaining TO-DO items for next session?
3. Update [`journal.md`](../journal.md) with completion record
4. Run: `cmtpsh` (commit + push changes)

> Clean session closure: retrospective + forward planning + persistent record. `cmtpsh` shorthand assumes user has custom alias for commit+push workflow.

---
> Maintains closing separation before the final directive.
If any section conflicts with user’s direct request, explicitly raise the conflict before proceeding.
> Call out conflicts rather than guessing at intent.

<!-- END -->
> Final marker for automation; leave untouched.
